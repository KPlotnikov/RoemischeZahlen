package de.roemischeZahlen;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class FXMLController {

	// Für die Labels
	@FXML TextField arabInLabel;
	@FXML TextField arabOutLabel;
	@FXML TextField romInLabel;
	@FXML TextField romOutLabel;
	
	// Für die Klassen
	private RoemischZuArabisch romToArab;
	private ArabischZuRoemisch arabToRom;

	@FXML private void romEinlesen() {
		romToArab = new RoemischZuArabisch(this);
		romToArab.roemischUmrechnen();
	}
	
	@FXML private void arabEinlesen() {
		arabToRom = new ArabischZuRoemisch(this);
		arabToRom.arabischUmrechnen();
	}

	TextField getArabOutLabel() {
		return arabOutLabel;
	}

	TextField getArabInLabel() {
		return arabInLabel;
	}

	TextField getRomInLabel() {
		return romInLabel;
	}

	TextField getRomOutLabel() {
		return romOutLabel;
	}

}
