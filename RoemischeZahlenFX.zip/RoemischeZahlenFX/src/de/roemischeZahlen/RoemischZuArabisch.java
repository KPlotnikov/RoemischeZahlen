package de.roemischeZahlen;

class RoemischZuArabisch {
	
	// Für die dezimale Zahl
	private int arabisch;
	
	// Für die Instanz des Kontrollers
	private FXMLController fxmlController;
	
	// Der Konstruktor
	RoemischZuArabisch(FXMLController fxmlController) {
		this.fxmlController = fxmlController;
	}
	
	// Die Methode startet die Umrechnung
	void roemischUmrechnen() {
		// Die roemische Zahl beziehen
		String roemisch = fxmlController.getRomInLabel().getText();
		
		// Umrechnen
		roemischEinzelnUmrechnen(roemisch);
	}
	
	/*
	* Die Methode rechnet die römische Zahlen in die arabische rekursiv um.
	* Ein römischer Zahl wird von links nach rechts ausgewertet.
	* Die ermittelte dezimale Zahl wird in der Variable 'arabisch' zusammen gerechnet.
	* Die ausgewertete römische Buchstaben werden aus der Zeichenkette entfernt.
	* Der Vorgang wierholt sich mit dem Rest.
	*/
	private void roemischEinzelnUmrechnen(String roemisch) {
		// Für die römische Zahlen
		char rom1 = ' ';
		char rom2 = ' ';
		// Für die arabische Zahlen
		int arab1 = 0;
		int arab2 = 0;
		// Für die Länge der römischen Zeichenkette
		int romLaenge = roemisch.length();
		
		rom1 = roemisch.charAt(0);
		arab1 = arabAusRom(rom1);
		
		// Gibt es noch eine weitere Zahl?
		if (romLaenge > 1) {
			rom2 = roemisch.charAt(1);
			arab2 = arabAusRom(rom2);
		} else {
			arabisch += arab1;
			// Ausgeben
			fxmlController.getArabOutLabel().setText(Integer.toString(arabisch));
			return;
		}
		
		// Ist die erste Zahl kleiner als die zweite?
		if (arab1 < arab2) {
			arabisch += arab2 - arab1;
			if (romLaenge > 2) {
				// Die ausgewrtete Zahlen abschneiden und neu berechnen
				roemischEinzelnUmrechnen(roemisch.substring(2)); 
			} else {
				// Ausgeben
				fxmlController.getArabOutLabel().setText(Integer.toString(arabisch));
				return;
			}
		}

		// Ist die erste Zahl größer als die zweite oder ihr gleich?
		if (arab1 >= arab2) {
			arabisch += arab1;
			if (romLaenge > 1) {
				// Die ausgewrtete Zahlen abschneiden und neu berechnen
				roemischEinzelnUmrechnen(roemisch.substring(1));
			} else {
				// Ausgeben
				fxmlController.getArabOutLabel().setText(Integer.toString(arabisch));
				return;
			}
		}
	}
	
	// Die Methode rechnet eine einzelne römische Zahl in eine arabische um
	// und gibt diese zurück
	private int arabAusRom(char roemisch) {

		int arabZahl = 0;
		
		switch(roemisch) {
		case 'M':
			arabZahl = 1000;
			break;
		case 'D':
			arabZahl = 500;
			break;
		case 'C':
			arabZahl = 100;
			break;
		case 'L':
			arabZahl = 50;
			break;
		case 'X':
			arabZahl = 10;
			break;
		case 'V':
			arabZahl = 5;
			break;	
		case 'I':
			arabZahl = 1;
			break;
		}
		return arabZahl;
	}

}
