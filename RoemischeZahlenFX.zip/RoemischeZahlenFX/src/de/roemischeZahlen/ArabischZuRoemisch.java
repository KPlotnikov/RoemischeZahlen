package de.roemischeZahlen;

class ArabischZuRoemisch {
	
	// Für die römische Zahl
	private StringBuilder roemisch;
	
	// Für die Aufspaltung der arabischen Zahl
	private int tausendM;
	private int fuenfhundertD;
	private int hundertC;
	private int fuenfzigL;
	private int zehnX;
	private int fuenfV;
	private int einsI;
	
	// Für die Instanz der Aufruferklasse
	private FXMLController fxmlController;
	
	// Der Konstruktor
	ArabischZuRoemisch(FXMLController fxmlController) {
		this.fxmlController = fxmlController;
		roemisch = new StringBuilder();
	}

	void arabischUmrechnen() {
		
		// Die arabische Zahl beziehen
		String arab = fxmlController.getArabInLabel().getText();
		
		// Aufspalten
		arabischeZahlSpalten(arab);
		
		// Römische Tausender bilden
		setTausend(tausendM);
		// Fünfhunderter
		setFuenfhundert();
		// Hunderter
		setHunderter(hundertC);
		// Fünfziger
		setFuenfzig();
		// Zehner
		setZehner(zehnX);
		// Fünfer
		setFuenf();
		// Einsen
		setEinser(einsI);
		
		// Ausgeben
		fxmlController.getRomOutLabel().setText(roemisch.toString());
	}
	
	// Die Methode spaltet eine arabische Zahl auf die Bestandteile auf.
	private void arabischeZahlSpalten(String arab) {
		
		int zahl = Integer.parseInt(arab);

		int tausendXTemp = (int) zahl / 1000;
		tausendM = tausendXTemp * 1000;
		
		zahl -= tausendM;
		int fuenfhundertTemp = (int) (zahl) / 500;
		fuenfhundertD = fuenfhundertTemp * 500;

		zahl -= fuenfhundertD;
		int hundertXTemp = (int) (zahl) / 100;
		hundertC = hundertXTemp * 100;

		zahl -= hundertC;
		int fuenfzigTemp = (int) (zahl) / 50;
		fuenfzigL = fuenfzigTemp * 50;

		zahl -= fuenfzigL;
		int zehnXTemp = (int) (zahl) / 10;
		zehnX = zehnXTemp * 10;

		zahl -= zehnX;
		int fuenfTemp = (int) (zahl) / 5;
		fuenfV = fuenfTemp * 5;

		zahl -= fuenfV;
		einsI = zahl;
	}
	
	// Die Methode stellt die römische Tausender Buchstaben rekursiv zusammen
	private void setTausend(int zahl) {
		
		if (zahl == 900)
			return;

		int grenze = fuenfhundertD + hundertC;

		if (zahl == 0 && grenze == 900) {
			return;
		} else {
			if (zahl == 0)
				return;
		}
		
		roemisch.append("M");
		setTausend(zahl - 1000);
	}
	
	// Die Methode fügt die römische Fünfhundert oder Neunhundert hinzu
	private void setFuenfhundert() {

		int grenze = fuenfhundertD + hundertC;
		
		if (grenze == 900) {
			roemisch.append("CM");
			return;
		}

		if (fuenfhundertD == 0 && hundertC <= 300)
			return;
		
		if  (fuenfhundertD == 0 && hundertC == 400) {
			roemisch.append("CD");
			return;
		} else {
			roemisch.append("D");
		}
	}
	
	// Die Methode fügt diu römische Hunderter Buchstaben rekursiv hinzu
	private void setHunderter(int hundert) {

		if (hundert == 400)
			return;
		
		int grenze = fuenfzigL + zehnX;

		if (hundert == 0 && grenze == 90) {
			return;
		} else {
			if (hundert == 0)
				return;
		}
		
		roemisch.append("C");
		setHunderter(hundert - 100);
	}
	
	// Die Methode fügt die römische Fünfziger oder Neunzig hinzu
	private void setFuenfzig() {

		int grenze = fuenfzigL + zehnX;
		
		if (grenze == 90) {
			roemisch.append("XC");
			return;
		}

		if (fuenfzigL == 0 && zehnX <= 30)
			return;
		
		if  (fuenfzigL == 0 && zehnX == 40) {
			roemisch.append("XL");
			return;
		} else {
			roemisch.append("L");
		}
	}
	
	// Die Methode fügt die römische Zehner Buchstaben rekursiv hinzu
	private void setZehner(int zehn) {
		if (zehn == 40)
			return;
		
		int grenze = fuenfV + einsI;

		if (zehn == 0 && grenze == 9) {
			return;
		} else {
			if (zehn == 0)
				return;
		}
		
		roemisch.append("X");
		setZehner(zehn - 10);
	}
	
	// Die Methode fügt die römische Fünfer oder Neun hinzu
	private void setFuenf() {
		
		int grenze = einsI + fuenfV;
		
		if (grenze == 9) {
			roemisch.append("IX");
			return;
		}

		if (fuenfV == 0 && einsI <= 3)
			return;
		
		if  (fuenfV == 0 && einsI == 4) {
			roemisch.append("IV");
			return;
		} else {
			roemisch.append("V");
		}
	}
	
	// Die Methode fügt die römische Einsen Buchstabe rekursiv hinzu
	private void setEinser(int eins) {
		if (eins == 0 || eins == 4)
			return;

		roemisch.append("I");
		setEinser(eins - 1);
	}

}
