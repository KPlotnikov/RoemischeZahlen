package de.roemischeZahlen;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class Zahlen_Main extends Application {
	
	private static final String GUI = "RoemischeZahlenGUI.fxml";
	
	private static final String TITEL = "Römische Zahlen";
	
	// Icon path
	private static final String ICON = "/de/roemischeZahlen/icons/icon.png";

	@Override
	public void start(Stage stage) throws Exception {
		// Eine Instanz von FXMLLoader erzeugen
		FXMLLoader loader = new FXMLLoader(getClass().getResource(GUI));
		// Die Datei laden
		Parent root = loader.load();

		// Die Szene erzeugen
		Scene scene = new Scene(root, 475, 310);

		// Den Titel über stage setzen
		stage.setTitle(TITEL);
		// Das Icon setzen
		stage.getIcons().add(new Image(ICON));
		// Die Szene setzen
		stage.setScene(scene);
		// Größenänderung verhindern
		stage.setResizable(false);
		// und anzeigen
		stage.show();
		
	}
	public static void main(String[] args) {
		launch(args);
	}
}
