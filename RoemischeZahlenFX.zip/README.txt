Das Programm wandelt römische Zahlen in Dezimalzahlen und zurück um.
Allerdings funktioniert es nur bis 3999 korrekt und die römischen Zahlen
müssen korrekt eingegeben werden.

Das ist ein Eclipse-Projekt.

!!! Anbindung des JavaFX Moduls erforderlich.